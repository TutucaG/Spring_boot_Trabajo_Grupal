package com.example;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere una base MySQL local configurada en application.properties")
class MainTests {

	@Test
	void contextLoads() {
	}

}
