package com.example.config;

import com.example.entidades.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Slf4j
@Component
public class CargaDatosInicial implements CommandLineRunner {

    @PersistenceContext
    private EntityManager em;

    @Value("${app.cargar-datos-prueba:true}")
    private boolean cargarDatosPrueba;

    @Override
    @Transactional
    public void run(String... args) {
        if (!cargarDatosPrueba) {
            log.info("Carga de datos de prueba desactivada (app.cargar-datos-prueba=false).");
            return;
        }

        Long cantidad = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class).getSingleResult();
        if (cantidad > 0) {
            // ya hay datos en ESTA base, no se agrega nada
            log.info("La base ya tiene {} factura(s); no se cargan datos de prueba.", cantidad);
            return;
        }

        // ---------- Datos base ----------
        Usuario usuario = primero(Usuario.class);
        if (usuario == null) {
            usuario = new Usuario();
            usuario.setUsuario("admin");
            usuario.setClave("admin");
            usuario.setNombre("Administrador");
            usuario.setApellido("Sistema");
            em.persist(usuario);
        }

        PuntoVenta puntoVenta = primero(PuntoVenta.class);
        if (puntoVenta == null) {
            puntoVenta = new PuntoVenta();
            puntoVenta.setNumero(1);
            puntoVenta.setDescripcion("Sucursal Central");
            puntoVenta.setTipoEmision("CAE");
            puntoVenta.setDomicilioComercial("Av. San Martin 100");
            auditar(puntoVenta, usuario);
            em.persist(puntoVenta);
        }

        CondicionIva condicionIva = primero(CondicionIva.class);
        if (condicionIva == null) {
            condicionIva = new CondicionIva();
            condicionIva.setCodigoAfip(1);
            condicionIva.setDenominacion("IVA Responsable Inscripto");
            auditar(condicionIva, usuario);
            em.persist(condicionIva);
        }

        TipoMoneda tipoMoneda = primero(TipoMoneda.class);
        if (tipoMoneda == null) {
            tipoMoneda = new TipoMoneda();
            tipoMoneda.setCodigoAfip("PES");
            tipoMoneda.setDenominacion("Pesos Argentinos");
            tipoMoneda.setSimbolo("$");
            auditar(tipoMoneda, usuario);
            em.persist(tipoMoneda);
        }

        Cliente cliente = primero(Cliente.class);
        if (cliente == null) {
            Contacto contacto = new Contacto();
            contacto.setEmail("contacto@empresatech.com");
            contacto.setTelefono("0261-4000000");
            contacto.setCelular("261-5000000");
            em.persist(contacto);

            Domicilio domicilio = new Domicilio();
            domicilio.setNombreCalle("Belgrano");
            domicilio.setNumeroCalle("250");
            em.persist(domicilio);

            cliente = new Cliente();
            cliente.setCuitCuil("30-12345678-9");
            cliente.setDenominacion("Empresa Tech S.A.");
            cliente.setContacto(contacto);
            cliente.setDomicilio(domicilio);
            auditar(cliente, usuario);
            em.persist(cliente);
        }

        ListaPrecioArticulo listaPrecioArticulo = primero(ListaPrecioArticulo.class);
        if (listaPrecioArticulo == null) {
            Rubro rubro = new Rubro();
            rubro.setDenominacion("Bebidas");
            rubro.setCodigo(1);
            auditar(rubro, usuario);
            em.persist(rubro);

            Marca marca = new Marca();
            marca.setDenominacion("Coca-Cola");
            marca.setCodigo(1);
            auditar(marca, usuario);
            em.persist(marca);

            Articulo articulo = new Articulo();
            articulo.setRubro(rubro);
            articulo.setMarca(marca);
            articulo.setCodigo("ART-001");
            articulo.setDenominacion("Gaseosa 500ml");
            auditar(articulo, usuario);
            em.persist(articulo);

            ListaPrecio listaPrecio = new ListaPrecio();
            listaPrecio.setCodigo("LP-01");
            listaPrecio.setDenominacion("Lista General");
            auditar(listaPrecio, usuario);
            em.persist(listaPrecio);

            listaPrecioArticulo = new ListaPrecioArticulo();
            listaPrecioArticulo.setListaPrecio(listaPrecio);
            listaPrecioArticulo.setArticulo(articulo);
            listaPrecioArticulo.setPrecioVenta(750.0);
            auditar(listaPrecioArticulo, usuario);
            em.persist(listaPrecioArticulo);
        }

        // ---------- Facturas de ejemplo ----------
        // numero, fecha, importe, estado, cliente (null = Consumidor Final), cantidad de items
        List<FacturaVenta> facturas = new ArrayList<>();
        facturas.add(crearFactura(1001L, LocalDate.of(2026, 3, 15), 1500.0, "EMITIDA", null, 2, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1002L, LocalDate.of(2026, 3, 20), 85000.5, "EMITIDA", cliente, 5, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1003L, LocalDate.of(2026, 4, 2), 12500.0, "EMITIDA", cliente, 3, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1004L, LocalDate.of(2026, 4, 10), 4300.0, "ANULADA", null, 1, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1005L, LocalDate.of(2026, 5, 5), 52000.0, "EMITIDA", cliente, 2, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1006L, LocalDate.of(2026, 5, 20), 800.0, "EMITIDA", null, 1, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));
        facturas.add(crearFactura(1007L, LocalDate.of(2026, 6, 1), 23000.0, "ANULADA", cliente, 2, usuario, puntoVenta, condicionIva, tipoMoneda, listaPrecioArticulo));

        for (FacturaVenta f : facturas) {
            em.persist(f); // los detalles se guardan solos por el cascade
        }
        log.info("Datos de prueba cargados: {} facturas.", facturas.size());
    }

    private FacturaVenta crearFactura(Long numero, LocalDate fecha, double importe, String estado,
                                      Cliente cliente, int items, Usuario usuario, PuntoVenta puntoVenta,
                                      CondicionIva condicionIva, TipoMoneda tipoMoneda,
                                      ListaPrecioArticulo listaPrecioArticulo) {
        Date fechaEmision = java.sql.Date.valueOf(fecha);

        FacturaVenta f = new FacturaVenta();
        f.setNumero(numero);
        f.setFechaEmision(fechaEmision);
        f.setPuntoVenta(puntoVenta);
        f.setCliente(cliente);
        f.setCondicionIva(condicionIva);
        f.setTipoMoneda(tipoMoneda);
        f.setImporteTotal(importe);
        f.setImporteSaldo(importe);
        f.setEstado(estado);
        if ("ANULADA".equals(estado)) {
            f.setFechaAnulacion(fechaEmision);
        }
        auditar(f, usuario);

        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        double subtotal = importe / items;
        for (int i = 0; i < items; i++) {
            FacturaVentaDetalle d = new FacturaVentaDetalle();
            d.setFactura(f); // relacion bidireccional
            d.setListaPrecioArticulo(listaPrecioArticulo);
            d.setDescripcion("Gaseosa 500ml");
            d.setCantidad(1);
            d.setPrecioUnitario(subtotal);
            d.setImporteSubtotal(subtotal);
            detalles.add(d);
        }
        f.setDetalles(detalles);
        return f;
    }

    private void auditar(AuditoriaApp entidad, Usuario usuario) {
        Date ahora = new Date();
        entidad.setFechaAlta(ahora);
        entidad.setFechaModificacion(ahora);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }

    private <T> T primero(Class<T> clase) {
        List<T> lista = em.createQuery("SELECT e FROM " + clase.getSimpleName() + " e", clase)
                .setMaxResults(1)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }
}
