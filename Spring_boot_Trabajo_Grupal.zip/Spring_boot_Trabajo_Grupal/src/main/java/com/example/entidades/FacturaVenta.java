package com.example.entidades;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "factura_venta")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Se excluyen "detalles" (bucle recursivo) y las asociaciones LAZY (evita LazyInitializationException)
@EqualsAndHashCode(callSuper = true, exclude = {"detalles", "puntoVenta", "cliente", "condicionIva", "tipoMoneda"})
@ToString(exclude = {"detalles", "puntoVenta", "cliente", "condicionIva", "tipoMoneda"})
public class FacturaVenta extends AuditoriaApp {

    private Long numero;

    @Column(name = "fechaEmision", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaEmision;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "punto_venta_id", nullable = false)
    private PuntoVenta puntoVenta;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id", nullable = true)
    private Cliente cliente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tipo_moneda_id", nullable = false)
    private TipoMoneda tipoMoneda;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "condicion_iva_id", nullable = false)
    private CondicionIva condicionIva;

    @Column(name = "importeCobrado")
    private double importeCobrado;

    @Column(name = "importeSaldo")
    private double importeSaldo;

    @Column(name = "importeTotal", nullable = false)
    private double importeTotal;

    private String cae;

    @Column(name = "caeFechaVencimiento")
    @Temporal(TemporalType.DATE)
    private Date caeFechaVencimiento;

    @Column(name = "resultadoAfip")
    private String resultadoAfip;

    @Column(name = "motivoRechazo")
    private String motivoRechazo;

    @Column(nullable = false)
    private String estado;

    @Column(name = "fechaAnulacion")
    @Temporal(TemporalType.DATE)
    private Date fechaAnulacion;

    private String observaciones;

    // CascadeType.ALL + orphanRemoval: al borrar la factura se borran sus detalles
    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FacturaVentaDetalle> detalles;

}