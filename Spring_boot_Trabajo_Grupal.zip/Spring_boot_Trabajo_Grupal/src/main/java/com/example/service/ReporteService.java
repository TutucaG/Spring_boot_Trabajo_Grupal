package com.example.service;

import com.example.dto.FacturaReporteDTO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;


@Service
public class ReporteService {

    private static final String[] ENCABEZADOS = {
            "Nro Factura", "Fecha Emisión", "Cliente", "Condición IVA", "Punto Venta", "Importe Total", "Cant. Items"
    };
    private static final Locale AR = Locale.forLanguageTag("es-AR");

    // ---------------- PDF ----------------
    public byte[] generarPdf(List<FacturaReporteDTO> reporte) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        Font fuenteTitulo = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
        Font fuenteHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        Font fuenteCelda = new Font(Font.FontFamily.HELVETICA, 9);

        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4.rotate());
        try {
            PdfWriter.getInstance(documento, salida);
            documento.open();

            Paragraph titulo = new Paragraph("Reporte Ejecutivo de Ventas", fuenteTitulo);
            titulo.setSpacingAfter(15);
            documento.add(titulo);

            PdfPTable tabla = new PdfPTable(ENCABEZADOS.length);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{1.3f, 1.5f, 2.8f, 2.8f, 2.8f, 1.8f, 1.3f});

            for (String h : ENCABEZADOS) {
                PdfPCell celda = new PdfPCell(new Phrase(h, fuenteHeader));
                celda.setBackgroundColor(BaseColor.DARK_GRAY);
                celda.setPadding(5);
                tabla.addCell(celda);
            }

            double total = 0;
            for (FacturaReporteDTO dto : reporte) {
                tabla.addCell(celda(String.valueOf(dto.getNumeroFactura()), fuenteCelda, Element.ALIGN_LEFT));
                tabla.addCell(celda(sdf.format(dto.getFechaEmision()), fuenteCelda, Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getClienteDenominacion(), fuenteCelda, Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getCondicionIva(), fuenteCelda, Element.ALIGN_LEFT));
                tabla.addCell(celda(dto.getPuntoVentaDescripcion(), fuenteCelda, Element.ALIGN_LEFT));
                tabla.addCell(celda(String.format(AR, "$ %,.2f", dto.getImporteTotal()), fuenteCelda, Element.ALIGN_RIGHT));
                tabla.addCell(celda(String.valueOf(dto.getCantidadItems()), fuenteCelda, Element.ALIGN_RIGHT));
                total += dto.getImporteTotal();
            }
            documento.add(tabla);

            Paragraph pie = new Paragraph(
                    String.format(AR, "Total de facturas: %d  |  Importe total: $ %,.2f", reporte.size(), total),
                    new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD));
            pie.setSpacingBefore(15);
            documento.add(pie);

            documento.close();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo generar el PDF", e);
        }
        return salida.toByteArray();
    }

    private PdfPCell celda(String texto, Font fuente, int alineacion) {
        PdfPCell c = new PdfPCell(new Phrase(texto, fuente));
        c.setHorizontalAlignment(alineacion);
        c.setPadding(4);
        return c;
    }

    // ---------------- "Excel"  ----------------
    public byte[] generarExcelTxt(List<FacturaReporteDTO> reporte) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        StringBuilder sb = new StringBuilder("\uFEFF");
        sb.append(String.join("\t", ENCABEZADOS)).append("\r\n");

        for (FacturaReporteDTO dto : reporte) {
            sb.append(String.join("\t",
                            String.valueOf(dto.getNumeroFactura()),
                            sdf.format(dto.getFechaEmision()),
                            dto.getClienteDenominacion(),
                            dto.getCondicionIva(),
                            dto.getPuntoVentaDescripcion(),
                            String.format(AR, "%.2f", dto.getImporteTotal()),
                            String.valueOf(dto.getCantidadItems())))
                    .append("\r\n");
        }
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }
}
