package com.example.service;

import com.example.dto.FacturaReporteDTO;
import com.example.repository.FacturaVentaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class FacturaService {

    private final FacturaVentaRepository facturaVentaRepository;

    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta,
                                                           String estado, Double montoMinimo) {

        String estadoNormalizado = (estado == null || estado.trim().isEmpty())
                ? null
                : estado.trim().toUpperCase();

        return facturaVentaRepository.buscarFacturasFiltradas(
                fechaDesde, fechaHasta, estadoNormalizado, montoMinimo);
    }
}
