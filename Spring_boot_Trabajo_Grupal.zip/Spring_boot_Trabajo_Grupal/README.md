# Spring Boot - Trabajo Grupal (Lombok, DTOs y API REST)

API REST con Spring Boot 4, Spring Data JPA (Hibernate), MySQL y Lombok que devuelve
un reporte de facturas de venta como DTO (`FacturaReporteDTO`) con filtros opcionales,
y permite descargar ese mismo reporte en PDF y en un archivo de texto separado por
tabulaciones (abre en Excel).

## Configuración

1. Tener MySQL corriendo en `localhost:3306`.
2. Definir las credenciales con variables de entorno (la contraseña **no** se escribe en el código):
   - `DB_USER` (por defecto `root`)
   - `DB_PASSWORD` (por defecto vacía)
   - `DB_NAME` (por defecto `facturacion_tp`)

   En IntelliJ: *Run > Edit Configurations > Environment variables* → `DB_USER=miusuario;DB_PASSWORD=micontraseña`.
3. La base `facturacion_tp` y las tablas se crean solas (`createDatabaseIfNotExist` y `ddl-auto=update`).
   Se usa una base propia para que no se mezcle con datos de otros proyectos.
4. Al iniciar, **si la base no tiene ninguna factura**, la aplicación inserta datos de prueba
   (7 facturas y los datos base necesarios). Si ya hay facturas, no agrega nada y lo avisa en la consola.
   Se puede desactivar con `app.cargar-datos-prueba=false`.
5. Ejecutar `Main` (o `./gradlew bootRun`). Queda en `http://localhost:8080`.

## Endpoints

Los tres son GET y aceptan los mismos filtros opcionales:

| Parámetro | Descripción | Ejemplo |
|---|---|---|
| `fechaDesde` | Facturas desde esta fecha (`yyyy-MM-dd`) | `2026-03-01` |
| `fechaHasta` | Facturas hasta esta fecha (`yyyy-MM-dd`) | `2026-04-30` |
| `estado` | Estado de la factura | `EMITIDA`, `ANULADA` |
| `montoMinimo` | `importeTotal` mayor o igual al monto | `10000` |

| URL | Devuelve |
|---|---|
| `GET /api/facturas` | Lista en JSON |
| `GET /api/facturas/pdf` | Archivo PDF (se abre en el navegador) |
| `GET /api/facturas/excel` | Archivo `.txt` separado por tabulaciones |

Ejemplos:

```
http://localhost:8080/api/facturas
http://localhost:8080/api/facturas?estado=ANULADA
http://localhost:8080/api/facturas?montoMinimo=50000
http://localhost:8080/api/facturas?fechaDesde=2026-03-01&fechaHasta=2026-03-31
http://localhost:8080/api/facturas/pdf?estado=EMITIDA&montoMinimo=10000
http://localhost:8080/api/facturas/excel?fechaDesde=2026-04-01
```

## Estructura

```
src/main/java/com/example
├── controller   FacturaRestController   (endpoints GET)
├── service      FacturaService          (lógica y normalización de filtros)
│                ReporteService          (genera PDF y txt)
├── repository   FacturaVentaRepository  (consulta JPQL dinámica contra la base)
├── dto          FacturaReporteDTO
├── config       CargaDatosInicial       (datos de prueba)
└── entidades    (entidades JPA con Lombok)
```

Flujo: `Controller -> Service -> Repository -> Base de datos`.


